from django.apps import AppConfig


class OlufekoscrumyConfig(AppConfig):
    name = 'olufekoscrumy'
