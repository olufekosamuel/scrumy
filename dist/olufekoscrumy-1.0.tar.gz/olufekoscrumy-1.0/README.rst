
Scrumy App

Scrumy is just a basic platform for company to monitor tasks given to employees and even employers.

quick one:
1. add olufekoscrumy to your INSTALLED_APPS in settings.py
2. include url in your project urls.py
3. run python mange.py migrate to create olufekoscrumy models
4. start your server and enjoy scrumy

